let addtodoButton = document.getElementById('addtodo');
let todocontainer = document.getElementById('todocontainer');
let inputfeild = document.getElementById('inputfeild');




 addtodoButton.addEventListener('click', function() {
   var paragraph = document.createElement('p'); 
   paragraph.innerHTML = inputfeild.value;
   paragraph.classList.add('paragraph_styling');
   todocontainer .appendChild(paragraph);
   inputfeild.value = "";
 paragraph.addEventListener('click', function () {
    paragraph.style.textDecoration = "line-through";
 })
 paragraph.addEventListener('dblclick', function () {
 todocontainer.removeChild(paragraph);
 })
 })